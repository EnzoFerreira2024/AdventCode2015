/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.notasf;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Notas {

    double mat;
    double port;
    double ef;
    double fq;
    double psi;
    double ac;
    double ing;
    double rc;
    double so;
    double tic;
    double ai;

}
