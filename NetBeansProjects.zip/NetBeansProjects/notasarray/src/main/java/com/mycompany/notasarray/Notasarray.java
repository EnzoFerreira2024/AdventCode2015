/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.notasarray;

public class Notasarray {

    public static void main(String[] args) {
  int[] numeros = {9,5,14,12,18,10,20,15,14};
          int n = numeros.length;  

        
        for (int j = 0; j < n; j++) {
            if (j<=10) {
                
            }
         
        }
           System.out.println("aprovados: " +n);
           System.out.println("reprovados: " +n);
        
        
        
       }
    }

