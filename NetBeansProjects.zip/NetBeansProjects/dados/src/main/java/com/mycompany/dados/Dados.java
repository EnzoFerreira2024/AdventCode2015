package com.mycompany.dados;

import java.io.IOException;
import java.util.Scanner;

public class Dados {

    static dadoscolocar u = new dadoscolocar();

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int op;

        while (true) {
            

            System.out.println("**********MENU**********");
            System.out.println("\n1 - Introduzir dados");
            System.out.println("2 - Listar dados");
            System.out.println("0 - Sair do programa");
            System.out.println("\n************************");

            System.out.print("\nIntroduza a opção que deseja: ");
            op = s.nextInt();

            switch (op) {
                case 1:
                    introduzirDados();
                    break;
                case 2:
                    listarDados();
                    break;
                case 0:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Introduza uma opção válida");
                    break;
            }
        }
    }

    public static void introduzirDados() {
        Scanner ronaldooooo = new Scanner(System.in);

        System.out.println("\n\n------------------------------------");
        System.out.print("\nDigite o seu nome: ");
        //sem comentários
        u.nome = ronaldooooo.next();
        do {
            System.out.print("\nDigite o seu ano de nascimento: ");
            u.ano = ronaldooooo.nextInt();
        } while (u.ano <= 1950 || u.ano >= 2024);

        System.out.print("\nDigite a sua morada: ");
        u.morada = ronaldooooo.next();
        System.out.print("\nDigite o seu país de origem: ");
        u.país = ronaldooooo.next();
        System.out.println("\n---------------------------------");
    }

    public static void listarDados() {
        System.out.println("\n\n------------------------------------");
        System.out.println("O seu nome é: " + u.nome);
        System.out.print("A sua idade é: ");
        System.out.println(2024 - u.ano);
        System.out.println("A sua morada: " + u.morada);
        System.out.println("Você nasceu em: " + u.país);
        System.out.println("\n---------------------------------");
    }
}
