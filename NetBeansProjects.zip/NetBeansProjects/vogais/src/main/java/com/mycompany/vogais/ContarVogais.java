package com.mycompany.vogais;
import java.util.Scanner;
public class ContarVogais {
    public static void main(String[] args) {
        Scanner ronaldo = new Scanner(System.in);
        System.out.print("Digite uma frase: ");
        String frase = ronaldo.nextLine();
        int contadorVogais = contarVogais(frase);
        System.out.println("Número de consoantes na frase: " + contadorVogais);
        ronaldo.close();
    }
    public static int contarVogais(String frase) {
        if (frase == null) {
            return 0; 
        }
        int contar = 0;
        frase = frase.toLowerCase();
        
        //iterar por cada caractere da string desde o início até ao fim
        for (int i = 0; i < frase.length(); i++) {
            
            //extrai da string o caractare da posição i 
            char ch = frase.charAt(i);
            
            //caso o caractere não seja uma vogal incrementa 1 à varíavel contar
            if (ch != 'a' || ch != 'e' || ch != 'i' || ch != 'o' || ch != 'u') {
                contar++;
            }
        }
        return contar;
    }
}
