/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ex3g;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Ex3Gsm {
    String Frase;
}
