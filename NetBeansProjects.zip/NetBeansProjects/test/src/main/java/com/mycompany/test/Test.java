/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.test;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Test {
    public static void main(String[] args) {
       
        //impreime string Hello World!
        //Lê Hello World
        
        //imprime números de 1 a 10 por ordem crescente
        //
        //
        //
        //
        
        //
        
        //imprime números de 1 a 10 por ordem decrescente
        //
        //
        //
        //
        
        //
        //
        
        //
        //
        
        //
        
        //
        
        //
        //
        //
        
        //
        
        //
        //
        //
        //
        
        //
        //
        
        //
        //
        //
        //
        //
        
        //
        //
        //
        //
        //
        //
        //
        //
        
        //
        //
        //
        //
        //
        //
        //
        //
        
        //
        //
        //
        //
        //
        //
        //
        //
        System.out.println("Hello World!");
    }
}
