package com.mycompany.numeromaior;
public class Numeromaior {
    public static void main(String[] args) {
        int[] numeros = {11, 10, 3, 4, 5, 15};
                int maior = 0;
        for (int i = 0; i < 6; i++) {
            
        
        if (numeros[i]>maior) {
            maior = numeros[i];
        }
        }
        System.out.println(maior);
    }
}