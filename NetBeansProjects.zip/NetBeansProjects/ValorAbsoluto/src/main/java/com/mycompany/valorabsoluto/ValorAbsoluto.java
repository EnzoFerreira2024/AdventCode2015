/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.valorabsoluto;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class ValorAbsoluto {

    public static void main(String[] args) {
int numero = -10;
int valorAbsoluto = Math.abs(numero);
System.out.println(valorAbsoluto); 
    }
}
