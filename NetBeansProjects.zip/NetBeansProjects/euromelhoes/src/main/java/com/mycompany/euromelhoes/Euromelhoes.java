package com.mycompany.euromelhoes;
import java.util.Random;
public class Euromelhoes {

    public static void main(String[] args) {
        
        int numerosPrincipais = 0;
        Random random = new Random();

        while (numerosPrincipais <= 6) {
            int numero = random.nextInt(50) + 1;
            if (numerosPrincipais==0) 
            {
                
            }
        }
        int estrelas = 0;
        for (int i = estrelas; i < 2; i++) {
            int estrela = random.nextInt(12) + 1;
        }
       
            System.out.println("Números principais: " + numerosPrincipais);
        System.out.println("Estrelas: " + estrelas);
        }
    
        
    }



        

    

