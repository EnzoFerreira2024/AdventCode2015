/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.partida;


import java.util.Random;

class Team {
    private String name;
    private int score;

    public Team(String name) {
        this.name = name;
        this.score = 0;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public void scoreGoal() {
        this.score++;
    }
}

class HandballGame {
    private Team team1;
    private Team team2;
    private Random random;

    public HandballGame(Team team1, Team team2) {
        this.team1 = team1;
        this.team2 = team2;
        this.random = new Random();
    }

    public void simulateGame() {
        int gameDuration = 60; // Duração do jogo em minutos
        int eventsPerMinute = 2; // Média de eventos (tentativas de gol) por minuto

        for (int i = 0; i < gameDuration; i++) {
            for (int j = 0; j < eventsPerMinute; j++) {
                simulateEvent();
            }
        }

        printFinalScore();
    }

    private void simulateEvent() {
        int teamChance = random.nextInt(2); // Qual time vai tentar o gol, 0 ou 1
        int goalChance = random.nextInt(100); // Chance de marcar o gol

        if (goalChance < 30) { // 30% de chance de gol
            if (teamChance == 0) {
                team1.scoreGoal();
            } else {
                team2.scoreGoal();
            }
        }
    }

    private void printFinalScore() {
        System.out.println("Resultado Final:");
        System.out.println(team1.getName() + " " + team1.getScore() + " - " + team2.getScore() + " " + team2.getName());
    }
}

public class HandballSimulator {
    public static void main(String[] args) {
        Team team1 = new Team("Equipe A");
        Team team2 = new Team("Equipe B");

        HandballGame game = new HandballGame(team1, team2);
        game.simulateGame();
    }
}
