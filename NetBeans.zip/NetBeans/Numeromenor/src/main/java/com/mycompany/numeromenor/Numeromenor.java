/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.numeromenor;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Numeromenor {

    public static void main(String[] args) {
        int[] numeros = {11, 10, 3, 4, 5, 15, 18, 20, 14};
        int menor = numeros[0];
        for (int i = 0; i < numeros.length - 1; i++) {
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
        }
        System.out.println(menor);
    }
}
