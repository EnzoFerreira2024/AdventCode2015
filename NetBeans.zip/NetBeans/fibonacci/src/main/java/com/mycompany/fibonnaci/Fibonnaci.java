
package com.mycompany.fibonnaci;
public class Fibonnaci {
    public static void main(String[] args) {
        int a = 1;
        int b = 1;
        int c;
        int contador = 3; 
        
        System.out.println(a); 
        System.out.println(b);
        
        while (contador < 10) {
            c = a + b;        
            a = b;
            b = c;
            contador++;
            System.out.println( c ); 
        }
    }
}
