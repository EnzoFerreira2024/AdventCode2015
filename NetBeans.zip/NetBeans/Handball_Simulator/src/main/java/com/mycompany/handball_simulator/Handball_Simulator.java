/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.handball_simulator;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Handball_Simulator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        handball é vida simplesmente o maior depsorto de sempre o um verdadeiro AMOR é a melhor coisa que já existiu 
                
                E ESCREVO AQUI QUE PARA O ANO ESTOU NA SELEÇÃO.
    }
}
