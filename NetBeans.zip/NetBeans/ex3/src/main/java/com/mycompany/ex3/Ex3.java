/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex3;


import java.util.Scanner;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Ex3 {

    public static void main(String[] args) {
   Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o seu nome:");
        String nome = scanner.nextLine();
        System.out.println("Olá, " +nome+"!");
        int numeroDeCaracteres = nome.length();
        System.out.println(nome+ "tem" +numeroDeCaracteres);
        int i = numeroDeCaracteres-1;
        while (i >= 0)
        {
            System.out.println(nome.charAt(i));
            i--;
        }
     }
}
