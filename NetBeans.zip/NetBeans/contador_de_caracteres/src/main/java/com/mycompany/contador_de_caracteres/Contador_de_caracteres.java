/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contador_de_caracteres;
public class Contador_de_caracteres {
    public static void main(String[] args) {
       //tamanho
        int[] numeros = {1, 10, 3, 4, 5, 15};
        int n = numeros.length;
//        System.out.println(n);
        //fimtamanho do array
        int total= 0;
        double media = 0;        
        
//        total=total+numeros[0]; 
//        total=total+numeros[1]; 
//        total=total+numeros[2]; 
//        total=total+numeros[3]; 
//        total=total+numeros[4]; 
//        total=total+numeros[5]; 

        for (int i = 0; i < n; i++) {
//          System.out.println(numeros[i]);
            //total+=numeros[i];
            total=total+numeros[i];                   
        }
        media=total/(double)n;
        System.out.println(total);
        System.out.println(media);  
        
    }
}
