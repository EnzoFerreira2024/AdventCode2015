package com.mycompany.factorial;

public class Factorial {

    public static void main(String[] args) {
        int nr = 25;
        long factorial = 1;
        if (nr < 1) {
            System.err.println("ERRO1: o valor de n tem de ser igual ou superior a 1");
        } else if (factorial == 0) {
            System.err.println("ERRO2: Não é possível calcular o fatorial para um número tão grande");
        } else {
            for (long i = 1; i <= nr; i++) {
                factorial *= i;
            }
            System.out.println("O fatorial de " + nr + " é " + factorial);
        }
    }
    public static long f(long nr) {
        long res = 1;
        for (long i = 1; i <= nr; i++) {
            res *= i;
        }
        return res;
    }
}
