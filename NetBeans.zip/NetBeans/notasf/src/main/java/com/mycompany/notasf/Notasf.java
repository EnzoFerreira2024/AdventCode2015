/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.notasf;

import java.util.Scanner;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Notasf {

    public static void main(String[] args) {
        
        Scanner ronaldooooo = new Scanner(System.in); 
        Notas a = new Notas();
        System.out.println("Digite a sua nota de mat");
        a.mat = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de port");
        a.port = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de ef");
        a.ef = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de fq");
        a.fq = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de psi");
        a.psi = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de ac");
        a.ac = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de ing");
        a.ing = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de rc");
        a.rc = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de so");
        a.so = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de tic");
        a.tic = ronaldooooo.nextDouble(); 
        System.out.println("Digite a sua nota de ai");
        a.ai = ronaldooooo.nextDouble(); 
        do{
       
        
            
        } while (a.mat<=9.5 ||a.mat>=20||a.port<=9.5||a.port<=20||a.ef<=9.5||a.ef<=20||a.fq<=9.5||a.fq<=20||a.psi<=9.5||a.psi<=20||a.ac<=9.5||a.ac<=20||a.ing<=9.5||a.ing<=20||a.rc<=9.5||a.rc<=20||a.so<=9.5||a.so<=20||a.tic<=9.5||a.tic<=20||a.ai<=9.5||a.ai<=20);
        double média= a.mat+a.port+a.ef+a.fq+a.psi+a.ac+a.ing+a.rc+a.so+a.tic+a.ai/1;
        System.out.println(média);
    }
}
