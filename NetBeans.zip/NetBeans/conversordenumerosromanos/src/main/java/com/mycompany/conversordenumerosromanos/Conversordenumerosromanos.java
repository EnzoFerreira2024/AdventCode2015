/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.conversordenumerosromanos;

import java.util.Scanner;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Conversordenumerosromanos {

    public static void main(String[] args) {
Scanner input = new Scanner(System.in);
     int opcao;
      
     do {
    System.out.println("Escolha a operação, coloque o numero:");
    System.out.println("1. naturais para romanos");
    System.out.println("2. romanos para naturais");
             System.out.println("insira uma operação ");
             opcao=input.nextInt();
             
             if (opcao!=0)
                 System.out.println("Insira o nº");

             double n1 = input.nextDouble();
             switch(opcao){
                 case 1:
                     System.out.println("naturais para romanos " +(n1));
                     System.out.println(" ");
                     break;
                 case 2:
                     System.out.println("romanos para naturais " +(n1));
                     System.out.println(" ");
                     break;
             }
         }while (opcao!=0);
         System.err.println("Programa errado");
    }
}


