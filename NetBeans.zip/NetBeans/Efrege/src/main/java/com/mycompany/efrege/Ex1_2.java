

package com.mycompany.efrege;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ex1_2 {

    public static void main(String[] args) {

        int andar = 0;
        int posicao = 0;
        boolean encontrouPorao = false;

        try (BufferedReader br = new BufferedReader(new FileReader("inputt.txt"))) { 
            int ch;
            while ((ch = br.read()) != -1) {
                posicao++;
                if (ch == '(') {
                    andar++;
                } else if (ch == ')') {
                    andar--;
                }

                if (andar == -1 && !encontrouPorao) { 
                    System.out.println("Posição que entra no porão: " + posicao);
                    encontrouPorao = true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Andar final: " + andar);
    }
}
