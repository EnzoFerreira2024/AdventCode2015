package com.mycompany.exe2_2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Exe2_2 {

    public static void main(String[] args) {
        String ronaldo = "iinput.txt";
        ArrayList<int[]> presentes = new ArrayList();
        try (BufferedReader br = new BufferedReader(new FileReader(ronaldo))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dimensions = line.split("x");
                int l = Integer.parseInt(dimensions[0]);
                int w = Integer.parseInt(dimensions[1]);
                int h = Integer.parseInt(dimensions[2]);
                presentes.add(new int[]{l, w, h});
            }
        } catch (IOException e) {
           e.printStackTrace();
        }
        int[][] presentesArray = new int[presentes.size()][3];
        presentesArray = presentes.toArray(presentesArray);
        System.out.println(fitaTotalNecessaria(presentesArray));
    }         
    public static int fitaTotalNecessaria(int[][] presentes) {
        int fitaTotal=0;
        for (int[] presente : presentes) {
            int l = presente[0];
            int w = presente[1];
            int h = presente[2];
            int perimetro1 = 2 * (l + w);
            int perimetro2 = 2 * (w + h);
            int perimetro3 = 2 * (h + l);
            int menorPerimetro = Math.min(perimetro1, Math.min(perimetro2, perimetro3));
            int volume = l * w * h;
            fitaTotal += menorPerimetro + volume;
        }     
        return fitaTotal;
    }         
}             