/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.analisedetexto;

import java.util.Scanner;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Analisedetexto {

    public static void main(String[] args) {
////import java.util.*;
//
//public class TextAnalyzer {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter text:");
//        String text = scanner.useDelimiter("\\A").next();
//
//        int wordCount = countWords(text);
//        int sentenceCount = countSentences(text);
//        String mostCommonWord = findMostCommonWord(text);
//
//        System.out.println("Number of words: " + wordCount);
//        System.out.println("Number of sentences: " + sentenceCount);
//        System.out.println("Most common word: " + mostCommonWord);
//    }
//
//    public static int countWords(String text) {
//        String[] words = text.split("\\W+");
//        return words.length;
//    }
//
//    public static int countSentences(String text) {
//        String[] sentences = text.split("[.!?]");
//        return sentences.length;
//    }
//
//    public static String findMostCommonWord(String text) {
//        String[] words = text.split("\\W+");
//        Map<String, Integer> wordCounts = new HashMap<>();
//        for (String word : words) {
//            word = word.toLowerCase();
//            wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
//        }
//
//        String mostCommon = null;
//        int maxCount = 0;
//        for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
//            if (entry.getValue() > maxCount) {
//                mostCommon = entry.getKey();
//                maxCount = entry.getValue();
//            }
//        }
//        return mostCommon;
//    }
//}
        
    }
}
