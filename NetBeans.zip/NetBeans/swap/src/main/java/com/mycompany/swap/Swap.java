/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.swap;

/**
 *
 * @author PTC_AppDev_Trainee
 */    
public class Swap {
        
    public static void main(String[] args) {
    int a = 5;
      int b = 3;
      int c = 1;
      int temp = 0;
      //a = temp , b = a , temp = b
     temp = a;
     a = b;
     b = temp;
      
       System.out.println("a = "+a);
        System.out.println("b = "+b);
        
        

       
    }  
}
