
package com.mycompany.substituicao;

public class Substituicao {

 
    public static void main(String[] args) {
        String str = "Bom dia!";
        String result = replaceCharsAtEvenPositions(str);
        System.out.println("String modificada: " + result);
    }
    public static String replaceCharsAtEvenPositions(String str) {
        StringBuilder ronaldo = new StringBuilder();

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            if (i % 2 == 0) {
                ronaldo.append('*');  
            } else {
                ronaldo.append(ch);   
            }
        }
        return ronaldo.toString();
    }
}



