/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.medianotas;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Medianotas {

    public static void main(String[] args) {
        int[] numeros = {11, 10, 3, 4, 5, 15, 18, 20, 14};
        int total = 0;
        double media = 0;
        int cont = 0;
        
//        int menor = numeros[0];
        for (int i = 0; i < numeros.length; i++) {

            if (numeros[i] >= 10) {
               total=total+numeros[i];
               cont++;
            }

        }
        //System.out.println(menor);
        System.out.println(total);
        media  = total / (double)cont;
        System.out.println(media);
    }
    
}
