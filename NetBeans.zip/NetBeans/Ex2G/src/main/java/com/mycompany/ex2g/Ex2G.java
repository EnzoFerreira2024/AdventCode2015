/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ex2g;

import java.util.Scanner;

/**
 *
 * @author PTC_AppDev_Trainee
 */
public class Ex2G {

    public static void main(String[] args) {
         Scanner ronaldooooo = new Scanner(System.in); 
        Ex2Gsm a = new Ex2Gsm();
        System.out.println("Digite o seu nome");
        a.nome = ronaldooooo.next();
        System.out.println("Olá " +a.nome);
    }
}
